// GUARAMO — demonstração local. Não substitui um servidor seguro.
const translations = {
pt:{
nav_donations:"Doações",nav_help:"Ajuda",nav_jobs:"Empregos",nav_volunteers:"Voluntários",nav_diplomas:"Diplomas",language_label:"Idioma",
eyebrow:"ACOLHIMENTO • INFORMAÇÃO • OPORTUNIDADES",hero_title:"Um caminho de apoio para recomeçar.",hero_text:"Encontre informações sobre doações, serviços de apoio, oportunidades de trabalho e voluntariado.",hero_cta:"Encontrar apoio",hero_secondary:"Consultar doações",
eyebrow_donations:"REDE DE DOAÇÕES",donations_title:"Consulte os pontos de doação",donations_text:"Veja a disponibilidade informada em cada ponto. Os locais serão apresentados quando forem confirmados.",pending_title:"Locais em definição",pending_text:"Os cinco pontos de doação ainda não têm nomes e endereços confirmados. Por isso, não exibimos localizações fictícias.",
eyebrow_help:"APOIO E ORIENTAÇÃO",help_title:"Que tipo de ajuda você procura?",help_text:"Escolha uma área para conhecer as possibilidades de atendimento.",shelter_title:"Abrigos e acolhimento",shelter_text:"Consulte serviços de abrigo próximos usando sua localização ou informando uma região.",find_nearby:"Buscar locais próximos →",psych_title:"Apoio psicológico",psych_text:"Informações sobre atendimento com psicólogos e estudantes/estagiários sob supervisão profissional.",psych_note:"A disponibilidade e os locais de atendimento precisam ser confirmados pela equipe responsável.",work_support_title:"Orientação para trabalho",work_support_text:"Encontre oportunidades e pontos de atendimento ao trabalhador.",see_jobs:"Ver área de empregos →",
eyebrow_jobs:"TRABALHO E RENDA",jobs_title:"Empregos e atendimento ao trabalhador",jobs_text:"A área está preparada para apresentar vagas e pontos de atendimento quando houver informações verificadas.",job_search_title:"Buscar oportunidades",job_search_label:"Cargo, área ou palavra-chave",job_placeholder:"Ex.: auxiliar administrativo",search:"Buscar",worker_center_title:"Centros de atendimento",worker_center_text:"Você também poderá procurar pontos de atendimento ao trabalhador pela sua região.",
eyebrow_volunteers:"FAÇA PARTE DA REDE",volunteers_title:"Seja voluntário",volunteers_text:"Profissionais e estudantes podem demonstrar interesse em colaborar. O cadastro depende de análise e aprovação.",name:"Nome completo",area:"Área de atuação",institution:"Instituição de ensino ou trabalho",email:"E-mail",proof:"Diploma ou comprovante de matrícula (PDF ou imagem)",proof_help:"Demonstração local: o arquivo não é enviado a um servidor.",privacy:"Seus dados devem ser usados somente para avaliar o cadastro e entrar em contato. Nesta versão demonstrativa, os dados não são enviados nem armazenados em servidor.",send_registration:"Enviar cadastro para análise",
eyebrow_diplomas:"FORMAÇÃO E RECONHECIMENTO",diplomas_title:"Reconhecimento de diplomas",diplomas_text:"Área de orientação para migrantes que desejam buscar informações sobre o reconhecimento de diplomas obtidos em outro país.",diplomas_notice_title:"Informação importante",diplomas_notice_text:"Os procedimentos variam conforme o tipo de formação e as regras aplicáveis. Esta demonstração não apresenta etapas ou exigências legais não confirmadas.",
admin_title:"Área administrativa",admin_text:"Acesso reservado à equipe autorizada.",admin_login:"Entrar como administrador",admin_dashboard:"Painel administrativo",admin_demo_warning:"DEMONSTRAÇÃO: autenticação e dados ficam somente neste navegador. Não use informações reais.",manage_stock:"Gerenciar estoques",review_requests:"Solicitações",logout:"Sair",stock_update:"Atualizar estoque",donation_point:"Ponto de doação",item_name:"Item",quantity:"Quantidade",operation:"Operação",save_update:"Salvar atualização",no_backend_requests:"Sem solicitações reais",no_backend_text:"O envio de formulários não chega à administração nesta versão local. Para isso, será necessário configurar um backend seguro.",username:"Usuário",password:"Senha",enter:"Entrar",demo_credentials:"Credenciais demonstrativas: admin / gu aramo123 (troque antes de qualquer uso real).",footer_text:"Acolhimento, informação e oportunidades."
},
es:{
nav_donations:"Donaciones",nav_help:"Ayuda",nav_jobs:"Empleos",nav_volunteers:"Voluntariado",nav_diplomas:"Títulos",language_label:"Idioma",
eyebrow:"ACOGIDA • INFORMACIÓN • OPORTUNIDADES",hero_title:"Un camino de apoyo para volver a empezar.",hero_text:"Encuentra información sobre donaciones, servicios de apoyo, oportunidades de trabajo y voluntariado.",hero_cta:"Encontrar apoyo",hero_secondary:"Consultar donaciones",
eyebrow_donations:"RED DE DONACIONES",donations_title:"Consulta los puntos de donación",donations_text:"Consulta la disponibilidad informada en cada punto. Los lugares se mostrarán cuando estén confirmados.",pending_title:"Lugares por definir",pending_text:"Los cinco puntos de donación todavía no tienen nombres ni direcciones confirmados. Por eso, no mostramos ubicaciones ficticias.",
eyebrow_help:"APOYO Y ORIENTACIÓN",help_title:"¿Qué tipo de ayuda buscas?",help_text:"Elige un área para conocer las posibilidades de atención.",shelter_title:"Albergues y acogida",shelter_text:"Consulta servicios de alojamiento cercanos mediante tu ubicación o indicando una zona.",find_nearby:"Buscar lugares cercanos →",psych_title:"Apoyo psicológico",psych_text:"Información sobre atención con psicólogos y estudiantes/practicantes bajo supervisión profesional.",psych_note:"La disponibilidad y los lugares de atención deben ser confirmados por el equipo responsable.",work_support_title:"Orientación laboral",work_support_text:"Encuentra oportunidades y puntos de atención al trabajador.",see_jobs:"Ver sección de empleos →",
eyebrow_jobs:"TRABAJO E INGRESOS",jobs_title:"Empleos y atención al trabajador",jobs_text:"Esta sección está preparada para mostrar vacantes y puntos de atención cuando haya información verificada.",job_search_title:"Buscar oportunidades",job_search_label:"Puesto, área o palabra clave",job_placeholder:"Ej.: auxiliar administrativo",search:"Buscar",worker_center_title:"Centros de atención",worker_center_text:"También podrás buscar puntos de atención al trabajador en tu región.",
eyebrow_volunteers:"FORMA PARTE DE LA RED",volunteers_title:"Sé voluntario",volunteers_text:"Profesionales y estudiantes pueden manifestar su interés en colaborar. El registro requiere revisión y aprobación.",name:"Nombre completo",area:"Área de actuación",institution:"Institución educativa o laboral",email:"Correo electrónico",proof:"Título o comprobante de matrícula (PDF o imagen)",proof_help:"Demostración local: el archivo no se envía a un servidor.",privacy:"Tus datos deben utilizarse únicamente para evaluar el registro y contactar contigo. En esta versión de demostración, los datos no se envían ni se almacenan en un servidor.",send_registration:"Enviar registro para revisión",
eyebrow_diplomas:"FORMACIÓN Y RECONOCIMIENTO",diplomas_title:"Reconocimiento de títulos",diplomas_text:"Sección de orientación para migrantes que desean buscar información sobre el reconocimiento de títulos obtenidos en otro país.",diplomas_notice_title:"Información importante",diplomas_notice_text:"Los procedimientos varían según el tipo de formación y las normas aplicables. Esta demostración no presenta etapas ni requisitos legales no confirmados.",
admin_title:"Área administrativa",admin_text:"Acceso reservado al equipo autorizado.",admin_login:"Acceder como administrador",admin_dashboard:"Panel administrativo",admin_demo_warning:"DEMOSTRACIÓN: la autenticación y los datos permanecen solo en este navegador. No uses información real.",manage_stock:"Gestionar inventarios",review_requests:"Solicitudes",logout:"Salir",stock_update:"Actualizar inventario",donation_point:"Punto de donación",item_name:"Artículo",quantity:"Cantidad",operation:"Operación",save_update:"Guardar actualización",no_backend_requests:"No hay solicitudes reales",no_backend_text:"En esta versión local, los formularios no llegan a la administración. Para ello será necesario configurar un backend seguro.",username:"Usuario",password:"Contraseña",enter:"Entrar",demo_credentials:"Credenciales de demostración: admin / gu aramo123 (cámbialas antes de cualquier uso real).",footer_text:"Acogida, información y oportunidades."
},
en:{
nav_donations:"Donations",nav_help:"Support",nav_jobs:"Jobs",nav_volunteers:"Volunteers",nav_diplomas:"Diplomas",language_label:"Language",
eyebrow:"WELCOME • INFORMATION • OPPORTUNITIES",hero_title:"A path of support for a fresh start.",hero_text:"Find information about donations, support services, job opportunities and volunteering.",hero_cta:"Find support",hero_secondary:"View donations",
eyebrow_donations:"DONATION NETWORK",donations_title:"Check donation points",donations_text:"See the availability reported at each point. Locations will appear once confirmed.",pending_title:"Locations to be confirmed",pending_text:"The five donation points do not yet have confirmed names or addresses. We therefore do not display fictional locations.",
eyebrow_help:"SUPPORT AND GUIDANCE",help_title:"What kind of support are you looking for?",help_text:"Choose an area to learn about possible services.",shelter_title:"Shelters and accommodation",shelter_text:"Look for nearby shelter services using your location or entering an area.",find_nearby:"Find nearby places →",psych_title:"Psychological support",psych_text:"Information about support from psychologists and students/trainees under professional supervision.",psych_note:"Availability and service locations must be confirmed by the responsible team.",work_support_title:"Employment guidance",work_support_text:"Find job opportunities and worker assistance centers.",see_jobs:"View jobs section →",
eyebrow_jobs:"WORK AND INCOME",jobs_title:"Jobs and worker assistance",jobs_text:"This section is ready to display vacancies and assistance centers once verified information is available.",job_search_title:"Search opportunities",job_search_label:"Role, field or keyword",job_placeholder:"e.g. administrative assistant",search:"Search",worker_center_title:"Assistance centers",worker_center_text:"You will also be able to search for worker assistance centers in your area.",
eyebrow_volunteers:"JOIN THE NETWORK",volunteers_title:"Become a volunteer",volunteers_text:"Professionals and students can express interest in volunteering. Registration requires review and approval.",name:"Full name",area:"Area of expertise",institution:"Educational or work institution",email:"Email",proof:"Diploma or proof of enrollment (PDF or image)",proof_help:"Local demo: the file is not sent to a server.",privacy:"Your data should only be used to review your registration and contact you. In this demo version, data is not sent to or stored on a server.",send_registration:"Submit registration for review",
eyebrow_diplomas:"EDUCATION AND RECOGNITION",diplomas_title:"Diploma recognition",diplomas_text:"Guidance for migrants seeking information about recognition of diplomas obtained in another country.",diplomas_notice_title:"Important information",diplomas_notice_text:"Procedures vary according to the type of qualification and applicable rules. This demo does not provide unconfirmed legal steps or requirements.",
admin_title:"Administration area",admin_text:"Access reserved for authorized staff.",admin_login:"Administrator login",admin_dashboard:"Administration dashboard",admin_demo_warning:"DEMO: authentication and data remain only in this browser. Do not use real information.",manage_stock:"Manage stock",review_requests:"Requests",logout:"Log out",stock_update:"Update stock",donation_point:"Donation point",item_name:"Item",quantity:"Quantity",operation:"Operation",save_update:"Save update",no_backend_requests:"No real requests",no_backend_text:"Form submissions do not reach administrators in this local version. A secure backend is required for that.",username:"Username",password:"Password",enter:"Sign in",demo_credentials:"Demo credentials: admin / gu aramo123 (change before any real use).",footer_text:"Welcome, information and opportunities."
}
};

const points = Array.from({length:5}, (_,i)=>({id:i+1,name:`Ponto ${i+1}`,items:[]}));
let stock = JSON.parse(localStorage.getItem("guaramoStock") || "null") || points;
const languageSelect = document.getElementById("language");
const langTag = {pt:"pt-BR",es:"es",en:"en"};
function applyLanguage(lang){
  const dict = translations[lang] || translations.pt;
  document.documentElement.lang = langTag[lang] || "pt-BR";
  document.querySelectorAll("[data-i18n]").forEach(el=>{
    const key=el.dataset.i18n;
    if(dict[key]) el.textContent=dict[key];
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach(el=>{
    const key=el.dataset.i18nPlaceholder;
    if(dict[key]) el.placeholder=dict[key];
  });
  languageSelect.value=lang;
  renderStock();
}
languageSelect.addEventListener("change",e=>applyLanguage(e.target.value));

function renderStock(){
  const lang=languageSelect.value;
  const labels={pt:"Ponto",es:"Punto",en:"Point"};
  document.getElementById("publicStock").innerHTML=stock.map(p=>{
    const summary=p.items.length ? p.items.map(x=>`${escapeHTML(x.name)}: ${x.quantity}`).join(" • ") : (lang==="pt"?"Nenhum item cadastrado":lang==="es"?"No hay artículos registrados":"No items registered");
    return `<article class="stock-card"><p class="eyebrow">${labels[lang]} ${p.id}</p><h3>${labels[lang]} ${p.id}</h3><p>${summary}</p><span class="stock-status">${lang==="pt"?"Informação demonstrativa":lang==="es"?"Información de demostración":"Demo information"}</span></article>`;
  }).join("");
  const select=document.getElementById("stockPoint");
  if(select) select.innerHTML=stock.map(p=>`<option value="${p.id}">${labels[lang]} ${p.id}</option>`).join("");
  const list=document.getElementById("adminStockList");
  if(list) list.innerHTML=stock.map(p=>`<article class="admin-item"><strong>${labels[lang]} ${p.id}</strong><ul>${p.items.length?p.items.map(x=>`<li>${escapeHTML(x.name)} — ${x.quantity}</li>`).join(""):"<li>—</li>"}</ul></article>`).join("");
}
function escapeHTML(value){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
renderStock();

document.getElementById("menuToggle").addEventListener("click",()=>{
  const nav=document.getElementById("mobileNav");
  const open=nav.hidden;
  nav.hidden=!open;
  document.getElementById("menuToggle").setAttribute("aria-expanded",String(open));
});
document.querySelectorAll("#mobileNav a").forEach(a=>a.addEventListener("click",()=>{
  document.getElementById("mobileNav").hidden=true;
  document.getElementById("menuToggle").setAttribute("aria-expanded","false");
}));

document.querySelectorAll('[data-action="location"]').forEach(btn=>btn.addEventListener("click",async()=>{
  const target=btn.dataset.target;
  const result=document.getElementById(target==="shelter"?"shelterResult":"workerResult");
  if(!navigator.geolocation){result.textContent="Este navegador não disponibiliza geolocalização. Informe uma região manualmente à equipe responsável.";return;}
  result.textContent="Solicitando permissão de localização…";
  navigator.geolocation.getCurrentPosition(
    pos=>{result.textContent=`Localização obtida no navegador (latitude ${pos.coords.latitude.toFixed(3)}, longitude ${pos.coords.longitude.toFixed(3)}). Esta demonstração não consulta uma base de abrigos ou centros.`;},
    ()=>{result.textContent="Não foi possível obter a localização. Você pode informar uma região manualmente quando o serviço estiver conectado."},
    {enableHighAccuracy:false,timeout:8000}
  );
}));

document.getElementById("jobSearch").addEventListener("click",()=>{
  const q=document.getElementById("jobQuery").value.trim();
  document.getElementById("jobResult").textContent=q
    ?"Ainda não há uma base verificada de vagas conectada. A busca está pronta para receber essa integração."
    :"Digite um cargo, área ou palavra-chave para pesquisar.";
});
document.getElementById("volunteerForm").addEventListener("submit",e=>{
  e.preventDefault();
  const lang=languageSelect.value;
  document.getElementById("volunteerResult").textContent=lang==="pt"?"Formulário validado nesta demonstração. Nenhum dado ou documento foi enviado. A aprovação real exige integração com servidor seguro.":lang==="es"?"Formulario validado en esta demostración. No se enviaron datos ni documentos. La aprobación real requiere un servidor seguro.":"Form validated in this demo. No data or documents were sent. Real approval requires a secure server.";
  e.target.reset();
});

const dialog=document.getElementById("adminDialog");
document.getElementById("openAdmin").addEventListener("click",()=>dialog.showModal());
document.getElementById("loginForm").addEventListener("submit",e=>{
  e.preventDefault();
  const user=document.getElementById("adminUser").value;
  const pass=document.getElementById("adminPassword").value;
  // Credenciais locais de demonstração; não representam autenticação segura.
  if(user==="admin" && pass==="gu aramo123"){
    dialog.close();
    document.getElementById("adminPanel").hidden=false;
    document.getElementById("adminPanel").scrollIntoView({behavior:"smooth"});
    document.getElementById("loginResult").textContent="";
  }else{
    document.getElementById("loginResult").textContent="Usuário ou senha incorretos.";
  }
});
document.getElementById("adminLogout").addEventListener("click",()=>{
  document.getElementById("adminPanel").hidden=true;
  document.getElementById("openAdmin").focus();
});
document.querySelectorAll(".tab-button[data-tab]").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".tab-button[data-tab]").forEach(b=>b.classList.toggle("active",b===btn));
  document.getElementById("stocksTab").hidden=btn.dataset.tab!=="stocks";
  document.getElementById("requestsTab").hidden=btn.dataset.tab!=="requests";
}));
document.getElementById("saveStock").addEventListener("click",()=>{
  const pointId=Number(document.getElementById("stockPoint").value);
  const name=document.getElementById("stockItem").value.trim();
  const amount=Number(document.getElementById("stockQuantity").value);
  const action=document.getElementById("stockAction").value;
  const output=document.getElementById("stockAdminResult");
  if(!name || !Number.isInteger(amount) || amount<0){output.textContent="Informe um item e uma quantidade inteira igual ou maior que zero.";return;}
  const point=stock.find(p=>p.id===pointId);
  let item=point.items.find(x=>x.name.toLowerCase()===name.toLowerCase());
  if(!item){item={name,quantity:0};point.items.push(item);}
  if(action==="set") item.quantity=amount;
  if(action==="add") item.quantity+=amount;
  if(action==="remove"){
    if(amount>item.quantity){output.textContent="A quantidade a remover é maior que o estoque disponível.";return;}
    item.quantity-=amount;
  }
  localStorage.setItem("guaramoStock",JSON.stringify(stock));
  renderStock();
  output.textContent="Estoque atualizado neste navegador.";
  document.getElementById("stockItem").value="";
  document.getElementById("stockQuantity").value="";
});
applyLanguage("pt");
